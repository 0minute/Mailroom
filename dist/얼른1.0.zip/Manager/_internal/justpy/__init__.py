"""JustPy is an object-oriented, component based, high-level Python Web Framework that requires no front-end programming"""

from .justpy import *
__version__ = "0.5.6"
