Get-ChildItem -Path . -Recurse -Filter *.dll | Unblock-File
